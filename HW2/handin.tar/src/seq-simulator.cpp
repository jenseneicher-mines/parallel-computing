#include "make_unique.h"
#include "world.h"
#include "quad-tree.h"
#include <algorithm>
#include <iostream>

// TASK 1

// NOTE: You may modify any of the contents of this file, but preserve all function types and names.
// You may add new functions if you believe they will be helpful.

const int QuadTreeLeafSize = 8;
class SequentialNBodySimulator : public INBodySimulator
{
public:
    std::shared_ptr<QuadTreeNode> buildQuadTree(std::vector<Particle> & particles, Vec2 bmin, Vec2 bmax)
    {
 	std::vector<Particle> lessParticlesQ0;
 	std::vector<Particle> lessParticlesQ1;
 	std::vector<Particle> lessParticlesQ2;
 	std::vector<Particle> lessParticlesQ3;
	std::shared_ptr<QuadTreeNode> node = std::make_shared<QuadTreeNode>();


	if(particles.size() > QuadTreeLeafSize){                      // check if vector is greater than leaf size
		float x = ((bmin.x + bmax.x)/2.0);
		float y = ((bmin.y + bmax.y)/2.0);
		
		Vec2 bmin2;
		bmin2.x = x;
		bmin2.y = y;

	for(int i = 0; i < particles.size(); i++){		// split into 4 vectors, one for each quadrant and use in function calls below
		if(particles[i].position.x < bmin2.x && particles[i].position.y < bmin2.y) {
			lessParticlesQ0.push_back(particles[i]);
		}
		if(particles[i].position.x <= bmin2.x && particles[i].position.y > bmin2.y) {
			lessParticlesQ2.push_back(particles[i]);
		}	       
		if(particles[i].position.x > bmin2.x && particles[i].position.y <= bmin2.y) {
			lessParticlesQ1.push_back(particles[i]);
		}
		if(particles[i].position.x >= bmin2.x && particles[i].position.y >= bmin2.y) {
			lessParticlesQ3.push_back(particles[i]);
		}
	}

		Vec2 leftMid;
		leftMid.x = bmin.x;
		leftMid.y = y;

		Vec2 rightMid;
		rightMid.x = bmax.x;
		rightMid.y = y;

		Vec2 topMid;
		topMid.x = x;
		topMid.y = bmin.y;

		Vec2 botMid;
		botMid.x = x;
		botMid.y = bmax.y;

		node -> children[0] = buildQuadTree(lessParticlesQ0,bmin,bmin2);
		
		node -> children[1] = buildQuadTree(lessParticlesQ1,topMid,rightMid);

		node -> children[2] = buildQuadTree(lessParticlesQ2,leftMid,botMid);

		node -> children[3] = buildQuadTree(lessParticlesQ3,bmin2,bmax);
	}
	else{
		node -> isLeaf = true; 		// its a leaf node
		node -> particles = particles;  // set node
            }
	
       // TODO: implement a function that builds and returns a quadtree containing particles
       
        return node;
    }

    virtual std::shared_ptr<AccelerationStructure> buildAccelerationStructure(std::vector<Particle> & particles)
    {
        // build quad-tree
        auto quadTree = std::make_shared<QuadTree>();

        // find bounds
        Vec2 bmin(1e30f, 1e30f);
        Vec2 bmax(-1e30f, -1e30f);

        for (auto & p : particles)
        {
            bmin.x = fminf(bmin.x, p.position.x);
            bmin.y = fminf(bmin.y, p.position.y);
            bmax.x = fmaxf(bmax.x, p.position.x);
            bmax.y = fmaxf(bmax.y, p.position.y);
        }

        quadTree->bmin = bmin;
        quadTree->bmax = bmax;

        // build nodes
        quadTree->root = buildQuadTree(particles, bmin, bmax);
        if (!quadTree->checkTree()) {
          std::cout << "Your Tree has Error!" << std::endl;
        }

        return quadTree;
    }
    virtual void simulateStep(AccelerationStructure * accel, std::vector<Particle> & particles, std::vector<Particle> & newParticles, StepParameters params) override
    {

 
        // TODO: implement sequential version of quad-tree accelerated n-body simulation here,
        // using quadTree as acceleration structure
	//
	for(int i = 0; i < particles.size(); i++){
  
            std::vector<Particle> neighboringParticles;
	    auto pi = particles[i];
	    Vec2 force = Vec2(0.0f,0.0f);
            // accumulate attractive forces to apply to particle i
	    accel -> getParticles(neighboringParticles, particles[i].position, params.cullRadius);

            for (int j = 0; j < neighboringParticles.size(); j++)
            {
                force += computeForce(pi, neighboringParticles[j], params.cullRadius);
            }
            // update particle
            newParticles[i] = updateParticle(pi, force, params.deltaTime);
        }
    }
       
};

std::unique_ptr<INBodySimulator> createSequentialNBodySimulator()
{
    return std::make_unique<SequentialNBodySimulator>();
}
